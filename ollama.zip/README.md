# Support Ticket Classifier — Fine-tuning Qwen2.5

Fine-tune a small Qwen2.5 model to sort customer messages into 6 categories:
**Billing · Technical · Account · Shipping · Product Inquiry · Cancellation**

This is a complete, beginner-friendly fine-tuning project. Everything you need
is in this folder.

---

## What's inside

| File | What it is |
|------|-----------|
| `train.jsonl` | 229 labeled training examples (ready to use) |
| `val.jsonl` | 41 held-out examples for measuring accuracy |
| `finetune_qwen_colab.ipynb` | The notebook that does the training (run in Google Colab) |
| `generate_data.py` | The script that generated the data — edit it to add your own categories |

---

## The 5-minute version

1. Open **[Google Colab](https://colab.research.google.com)** and upload `finetune_qwen_colab.ipynb`
2. In Colab: `Runtime → Change runtime type → GPU (T4)`
3. Run the cells top to bottom. When prompted, upload `train.jsonl` and `val.jsonl`
4. Training takes ~5–15 minutes on the free GPU
5. The last cells test it and let you download the result

You do **not** need a powerful PC — the training runs on Google's free GPU, not
your machine. Your 4 GB GPU is only used later to *run* the finished model.

---

## How it works (the concepts)

**Fine-tuning** adjusts a pre-trained model to be good at one specific task.
We're not teaching Qwen new facts — we're teaching it a *behavior*: "when you
see a support message, reply with exactly one category name."

**QLoRA** is what makes this cheap. Instead of retraining all 3 billion
parameters, we:
- Load the model in 4-bit (quantized) to save memory
- Freeze it, and train tiny "adapter" layers on top (~1% of the size)

That's why it fits on a free GPU and finishes in minutes.

**The data format** is a chat conversation per example:
```json
{"messages": [
  {"role": "system", "content": "You are a support ticket classifier..."},
  {"role": "user", "content": "I was double charged this month"},
  {"role": "assistant", "content": "Billing"}
]}
```
The model learns to produce the `assistant` turn given the `system` + `user` turns.

---

## Making it your own

Want different categories, or to classify your *own* kind of text? Edit
`generate_data.py`:

1. Change the `DATA` dictionary — each key is a category, each has a list of
   example message templates with `{slots}` for variety.
2. Adjust the `SYSTEM` prompt to list your categories.
3. Re-run: `python3 generate_data.py`
4. Upload the new `train.jsonl` / `val.jsonl` to the notebook.

The same pipeline works for **any** classification task — spam detection,
intent routing, content tagging, priority levels, etc. Just swap the data.

---

## Running the finished model

The notebook can export your model two ways:

- **LoRA adapter** (a few MB) — for use with the base model in Python
- **GGUF file** — runs directly in **Ollama** on your PC, and works in the chat
  UI you built. Instructions are in the last notebook cell.

Once it's in Ollama as `ticket-classifier`, you can select it in your Local AI
Studio dropdown and classify tickets right from the chat interface.

---

## Tips for better results

- **More data helps** — 45 examples/category is a solid start; 100+ is better.
- **Balance matters** — keep categories roughly even (the generator does this).
- **Keep the system prompt identical** during training and use — the model
  learns to expect it.
- **If accuracy is low**, add more varied examples for the categories it confuses,
  then retrain. Fine-tuning is iterative.
- **Watch the loss** in training — it should trend downward. If it plateaus high,
  you may need more/better data or more epochs.
